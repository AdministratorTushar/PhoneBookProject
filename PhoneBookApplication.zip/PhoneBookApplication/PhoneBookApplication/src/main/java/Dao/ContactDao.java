package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Dto.Contact;

public class ContactDao {

	private Connection conn;

	public ContactDao(Connection conn) {
		super();
		this.conn = conn;
	};
	public ContactDao()
	{
		
	}
	
	public boolean saveContact(Contact c) 
	{
		boolean f=false;
		String query="insert into contact(name,email,phno,usreId,about) values(?,?,?,?,?)";
		try {
			PreparedStatement pstmt=conn.prepareStatement(query);
			
			pstmt.setString(1,c.getName());
			pstmt.setString(2, c.getEmail());
			pstmt.setString(3,c.getPhno());	
			pstmt.setInt(4,c.getUserId());
			pstmt.setString(5, c.getAbout());
			
			int i=pstmt.executeUpdate();
			
			if(i==1) {
				f=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return f;
	}
	public List<Contact> getContact(int uId){
	List<Contact> list=new ArrayList<Contact>();
	Contact c=null;
	try {
		String query="select * from contact where usreId=?";
		PreparedStatement pstmt=conn.prepareStatement(query);
		pstmt.setInt(1,uId);
		
		ResultSet rs=pstmt.executeQuery();
		
		while(rs.next()) {
			
			c=new Contact();
			c.setId(rs.getInt(1));
			c.setName(rs.getString(2));
			c.setEmail(rs.getString(3));
			c.setPhno(rs.getString(4));
			c.setAbout(rs.getString(5));
			list.add(c);
			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return list;
	}

	public Contact getContactById(int cid) {
		Contact c=new Contact();
		String query="select * from contact where id=?";
	try {
		PreparedStatement pstmt=conn.prepareStatement(query);
		pstmt.setInt(1, cid);
		
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			c.setId(rs.getInt(1));
			c.setName(rs.getString(2));
			c.setEmail(rs.getString(3));
			c.setPhno(rs.getString(4));
			c.setAbout(rs.getString(6));
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return c;
	}
	
	
	public int updateContact(Contact c1) {
		
		int data=0;
		String querry="update contact set name=?,phno=?,email=?,about=? where id=? ";
		try {
			PreparedStatement pstmt=conn.prepareStatement(querry);
			pstmt.setString(1, c1.getName());
			pstmt.setString(2, c1.getPhno());
			pstmt.setString(3, c1.getEmail());
			pstmt.setString(4, c1.getAbout());
			pstmt.setInt(5, c1.getId());
			 data=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
		
		
	}
	public int deleteContact(Contact c1) {
		
		int count=0;
		String querry="delete from contact where id=?";
		try {
			PreparedStatement pstmt=conn.prepareStatement(querry);
			pstmt.setInt(1, c1.getId());
			count=pstmt.executeUpdate();
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return count;
	}
	
}
