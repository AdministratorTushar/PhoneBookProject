package Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Connection.DBConnection;
import Dao.ContactDao;
import Dto.Contact;

@WebServlet("/delete")

public class DeleteContact extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id=Integer.parseInt(req.getParameter("id1"));
		Contact c1=new Contact(id);
		ContactDao d1=new ContactDao(DBConnection.getcon());
		int data=d1.deleteContact(c1);
		HttpSession ses=req.getSession();
		
		if(data>0) 
		{
			ses.setAttribute("successMsg", "Your Contact Delete SuccessFuly");
			resp.sendRedirect("view.jsp");
		}else {
			ses.setAttribute("failMsg", "Somthing went on server");
			resp.sendRedirect("view.jsp");
		}
	}
}
