package Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/loggedout")
public class LogoutServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	HttpSession ses=req.getSession();
	
	ses.removeAttribute("user");
	
	
	HttpSession ses2=req.getSession();
	ses2.setAttribute("logMsg", "Logout Susccessfuuly");
	resp.sendRedirect("login.jsp");
	}

}
