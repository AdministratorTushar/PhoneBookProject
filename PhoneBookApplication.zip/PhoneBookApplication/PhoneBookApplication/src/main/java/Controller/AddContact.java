package Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;

import Connection.DBConnection;
import Dao.ContactDao;
import Dto.Contact;
@WebServlet("/contact")
public class AddContact extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int userid=Integer.parseInt(req.getParameter("userId"));
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String phno=req.getParameter("phno");
		String about=req.getParameter("about");		
		Contact c=new Contact(name,email,phno,about,userid);
		ContactDao dao=new ContactDao(DBConnection.getcon());
		HttpSession ses=req.getSession();
		boolean f=dao.saveContact(c);
		if(f) 
		{
			ses.setAttribute("successMsg", "Your Contact Saved");
			resp.sendRedirect("add.jsp");
		}else {
			ses.setAttribute("failMsg", "Somthing went on server");
			resp.sendRedirect("add.jsp");
		}
	}
}
