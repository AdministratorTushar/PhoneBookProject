package Controller;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Connection.DBConnection;
import Dao.UserDao;
import Dto.User;
@WebServlet("/firstlogin")
public class LoginServelt extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String email=req.getParameter("email");
	String password=req.getParameter("password");

	
	UserDao dao=new UserDao(DBConnection.getcon());
	User user=dao.loginUser(email, password);
	
	HttpSession ses=req.getSession();
	
	if(user!=null) {
		ses.setAttribute("user",user);
		resp.sendRedirect("index.jsp");

	}else {
		ses.setAttribute("invalidMsg","Incorrect Username Or Password");
		resp.sendRedirect("login.jsp");

	}
}
	
}	
